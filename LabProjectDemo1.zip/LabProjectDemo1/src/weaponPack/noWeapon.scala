package weaponPack

class noWeapon extends Weapon
{
  this.name = "none"
  this.damage = 0
  this.bulletSpeed = 0
  this.location = List(0, 0)
}

package game
import playerPack._
import weaponPack._

object testGame
{
  val game = new Game
  def main(args: Array[String]): Unit =
  {

  }
}
